package pages;

/**
 * Created by Progres on 24.3.2018 г..
 */
public class LoginPage {

}
